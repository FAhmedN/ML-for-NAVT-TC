# 🧵 Tailor Shop ChatBot

A simple machine learning-style chatbot for a tailor shop that:
- Collects customer's name and dress measurements
- Offers pricing based on dress type
- Confirms order via interactive Web UI

## 🚀 How to Run

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/tailor-chatbot.git
   cd tailor-chatbot
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Start the Flask server:
   ```bash
   python app.py
   ```

4. Open your browser and go to:
   ```
   http://127.0.0.1:5000/
   ```

## 🛠️ Tech Stack

- Python (Flask)
- HTML + JS for frontend

## 📂 Project Structure

```
tailor-chatbot/
├── app.py            # Main application logic
├── templates/
│   └── index.html    # Web UI frontend
├── static/           # Optional: CSS/images
├── requirements.txt  # Dependencies
└── README.md         # Project documentation
```
