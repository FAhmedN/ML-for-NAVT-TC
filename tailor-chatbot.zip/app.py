from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

prices = {
    "Shalwar Kameez": 1500,
    "Pant Shirt": 2000,
    "Kurta": 1200,
    "Blazer": 5000
}

def tailor_bot(message, context):
    if "name" not in context:
        context["name"] = message
        return f"Hi {context['name']}! What type of dress would you like to order? (Shalwar Kameez / Pant Shirt / Kurta / Blazer)", context

    elif "dress_type" not in context:
        if message not in prices:
            return "Sorry, we only stitch Shalwar Kameez, Pant Shirt, Kurta, and Blazer. Please choose one.", context
        context["dress_type"] = message
        return "Great! What is your chest size (in inches)?", context

    elif "chest" not in context:
        context["chest"] = message
        return "Noted. What is your waist size (in inches)?", context

    elif "waist" not in context:
        context["waist"] = message
        return "Got it. What is your length (in inches)?", context

    elif "length" not in context:
        context["length"] = message
        dress = context['dress_type']
        price = prices[dress]
        context["price"] = price
        summary = (
            f"Thank you, {context['name']}! Here is your order summary:\n"
            f"Dress: {context['dress_type']}\n"
            f"Chest: {context['chest']} in, Waist: {context['waist']} in, Length: {context['length']} in\n"
            f"Total Price: Rs. {price}\n"
            f"Do you want to confirm this order? (yes/no)"
        )
        return summary, context

    elif "confirmed" not in context:
        if message.lower() == "yes":
            context["confirmed"] = True
            return "Your order has been confirmed! Thank you for choosing us.", context
        else:
            return "Your order has been cancelled. Let us know if you change your mind.", context

    return "Is there anything else I can help you with?", context


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("message")
    session = request.json.get("context", {})
    response, updated_context = tailor_bot(user_input, session)
    return jsonify({"reply": response, "context": updated_context})

if __name__ == "__main__":
    app.run(debug=True)
